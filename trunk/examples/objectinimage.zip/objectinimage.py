'''
This script calculates the appearance of a target object in an image,
through the atmosphere, against a background.
Three bands are considered: 0.4-0.75 um, 3.5-4.5 um and 8-12 um.
Different target properties are used in each of the three bands.
In all three cases are the sun irradiance part of the signature,
but it only plays a significant role in the visible band.

This code expects the sun transmittance to be pre-calculated, but
the path radiance and transmittance for the path between the source
and receiver are calculated in this code, using Modtran.
For this purpose, this script must be placed in the same directory
as the modtran executable. This code was tested on Windows.

'''

import os,mmap,shutil
import numpy
import pyradi.rymodtran as rymodtran
import pyradi.ryplot as ryplot
import pyradi.ryplanck as ryplanck
import pyradi.ryutils as ryutils
import subprocess
import os.path, fnmatch, time
import contextlib
from scipy.interpolate import  interp1d

tempTarget = [1500+273, 500, 370] # for three spectral bands
emisTarget = [0.7, 0.8, 0.9]      # for three spectral bands
tempBackground = [300, 300, 300]  # for three spectral bands
emisBackground = [0.05, 0.8, 0.9] # for three spectral bands
tempSun = 5900    # K
thetaSun = 1.     # angle btween sun and surface normal
omegaPixel = 1e-6 # pixel field of view
areaTarget = 0.2  # area of the target

colour = 2          # 0=vis, 1=MWIR, 2=LWIR
calcModtran = True # if true do modtran, otherwise read npz files.

# the following files provide info for different spectral bands.
npfilenames = ['dataVIS.npz', 'dataMWIR.npz', 'dataLWIR.npz']
tape5filenames = ['tape5.VIS', 'tape5.MWIR', 'tape5.LWIR']
archivedirnames = ['archiveVIS', 'archiveMWIR', 'archiveLWIR']
tape7sunfilenames = ['tape7.VISSun','tape7.MWIRSun','tape7.LWIRSun']
caseHeadings = [r'0.4-0.75 $\mu$m', r'3.5-4.5 $\mu$m', r'8-12 $\mu$m']
caseAbbrev = [r'VIS', r'MWIR', r'LWIR']
graphScaling = [(1e-7, 1e-3),(1e-8, 1e-4),(1e-7, 1e-4), ]

if calcModtran:
    #get the appropriate tape5 file
    shutil.copyfile(tape5filenames[colour], 'tape5')
    #set up the distance grid (on log scale)
    pathlens = numpy.logspace(2, 5, 50)
    i = 0 # keep track of first and later passes
    #do for all distances in the list
    for pathlen in pathlens:
        print('Now doing range {0}'.format(pathlen))
        #use memory map to open, change and write the file.
        with open('tape5','r+') as f:
            with contextlib.closing(mmap.mmap(f.fileno(),0)) as m:
                strpathlenkm = str(int(pathlen)/1000.).zfill(10)
                m[306:316] = strpathlenkm
                m.flush()

        # execute modtran, here in the current working dir
        lstCmd = ['Mod5.2.0.0.exe']
        p=subprocess.Popen(lstCmd)
        while  p.poll() == None:
            time.sleep(0.5)

        #extract info from tape7
        colSelect =  ['FREQ', 'TOT_TRANS', 'TOTAL_RAD']
        tape7= rymodtran.loadtape7("tape7", colSelect )

        #if visible band, convolve and resample to reduce number of data points
        if colour == 0:
            tau7, x = ryutils.convolve(tape7[:,1].reshape(-1,1), 1,  2, 10)
            lpa7, x = ryutils.convolve(1e4 * tape7[:,2].reshape(-1,1), 1,  2, 10)
            nu7 = tape7[:,0]
            tauTab = interp1d(nu7,tau7)
            lpaTab = interp1d(nu7,lpa7)
            nu = nu7[0:-1:10].reshape(-1,1)
            tau = tauTab(nu).reshape(-1,1)
            lpa = lpaTab(nu).reshape(-1,1)
        else:
            tau = tape7[:,1].reshape(-1,1)
            lpa=  1e4 * tape7[:,2].reshape(-1,1)
            nu = tape7[:,0].reshape(-1,1)

        if i == 0:
            wavenu = nu
            transm = tau
            lpath  = lpa
        else:
            transm = numpy.hstack((transm,tau))
            lpath = numpy.hstack((lpath,lpa))

        #copy tape5 & 7 files to new filenames in archive
        tape5filename = 'tape5-'+str(int(pathlen)).zfill(6)
        tape7filename = 'tape7-'+str(int(pathlen)).zfill(6)
        shutil.copyfile('tape5','./'+archivedirnames[colour]+'/'+tape5filename)
        shutil.copyfile('tape7','./'+archivedirnames[colour]+'/'+tape7filename)

        i = i + 1

    #save summmary data for future reference
    numpy.savez(npfilenames[colour], transm=transm, lpath=lpath,
        pathlens=pathlens, wavenu=wavenu )

else:
    #read from summary data file, don't run modtran
    npzfiles = numpy.load(npfilenames[colour])
    transm = npzfiles['transm']
    lpath = npzfiles['lpath']
    wavenu = npzfiles['wavenu']
    pathlens = npzfiles['pathlens']

#predefine array to use later
# data in columns: Target, Background,Path and Total
Irradiance = numpy.zeros(shape = (pathlens.shape[0],4))
ESelect = ['Target','Background','Path','Total',  ]

#read sun to target transmittance data from tape7 data file
colSelect =  ['FREQ', 'TOT_TRANS']
tape7sun = rymodtran.loadtape7(tape7sunfilenames[colour], colSelect )
if colour == 0:
    tauTab = interp1d(tape7sun[:,0],tape7sun[:,1])
    tauSun = tauTab(wavenu).reshape(-1, 1)
else:
    tauSun = tape7sun[:,1].reshape(-1, 1)

#spectral radiance [W/(m$^2$.sr.cm$^{-1}$)]
LTarget = ryplanck.planck(wavenu, tempTarget[colour], type='en').reshape(-1, 1) \
          / numpy.pi
LBack = ryplanck.planck(wavenu, tempBackground[colour], type='en').reshape(-1, 1)\
         / numpy.pi
Lsun = ryplanck.planck(wavenu, tempSun, type='en').reshape(-1, 1) / numpy.pi
#background has self-radiance as well as reflected sunlight.
LBackground = LBack * emisBackground[colour] + \
      numpy.cos(thetaSun) * tauSun * (1 - emisBackground[colour])*Lsun*2.177e-5

#Now do for all ranges
for i in numpy.arange(0,pathlens.shape[0]):
    pathlen = pathlens[i]

    #multipy transmittance and integrate over wavelength [W/(m$^2$.sr)]
    LTargetInt=numpy.trapz(LTarget * transm[:,i].reshape(-1,1),\
        wavenu, axis=0)[0]
    LBackgroundInt=numpy.trapz(LBackground * transm[:,i].reshape(-1,1),\
        wavenu, axis=0)[0]
    LPathInt=numpy.trapz(lpath[:,i].reshape(-1,1),wavenu, axis=0)[0]

    print(pathlen,LTargetInt,LBackgroundInt,LPathInt)

    #target pixel field of view smaller than pixel fov
    omegaTarget = areaTarget / pathlen ** 2
    if omegaTarget > omegaPixel:
        omegaTarget = omegaPixel
    #background fov around target, inside pixel fov
    omegaBackground = omegaPixel - omegaTarget

    #relative contribution to pixel irradiance
    Irradiance[i,0] = omegaTarget * LTargetInt
    Irradiance[i,1] = omegaBackground * LBackgroundInt
    Irradiance[i,2] = omegaPixel * LPathInt
    Irradiance[i,3] = Irradiance[i,0] + Irradiance[i,1]  +Irradiance[i,2]

#plot spectral data - huge plot, takes a while
specplot = ryplot.Plotter(1, 2,1,"Atmospheric spectrals",figsize=(12,6))
specplot.plot(1,  wavenu, transm, "Transmittance","Wavenumber [cm$^{-1}$]", \
    "Transmittance",
         #legendAlpha=0.5, # label=colSelect, pltaxis=[3300, 4200, 0, 1],
         maxNX=10, maxNY=4, powerLimits = [-4,  4, -5, 5])
specplot.plot(2,  wavenu, lpath, "Path Radiance","Wavenumber [cm$^{-1}$]",\
     "L [W/(m$^2$.sr.cm$^{-1}$)]",
         #legendAlpha=0.5, # label=colSelect, pltaxis=[3300, 4200, 0, 1],
         maxNX=10, maxNY=4, powerLimits = [-4,  4, -5, 5])
specplot.saveFig('specplot.eps')

#plot irradiance data vs range
irradplot = ryplot.Plotter(1, 1, 1,
    "Object appearance in image: {0}".format(caseHeadings[colour]),
        figsize=(12,6))
irradplot.logLog(1, pathlens, Irradiance,"","Range [m]",
    "Irradiance [W/m$^2$]", legendAlpha=0.5, label=ESelect,
         pltaxis=[1e2, 1e5, graphScaling[colour][0], graphScaling[colour][1]],
         maxNX=10, maxNY=4, powerLimits = [-4,  4, -5, 5])
irradplot.saveFig('rangeplot{0}.eps'.format(caseAbbrev[colour]))

if colour == 0: # only for visible band
    #investigate atmospheric metereological range against this result.
    contrast =  (Irradiance[:,3]-Irradiance[:,2])/Irradiance[:,2]
    #find the range where contrast is 0.05
    contrastTable = interp1d(contrast[-1:0:-1], pathlens[-1:0:-1], \
                     kind = 'linear')
    rangeAtC = contrastTable(0.05)
    print(rangeAtC)

    contrastplot = ryplot.Plotter(1, 1, 1,
        "Object contrast in image: {0}".format(caseHeadings[colour]),
            figsize=(12,6))
    contrastplot.logLog(1, numpy.asarray([rangeAtC,rangeAtC]),
        numpy.asarray([0.01,0.1]), "", "", "",
             maxNX=10, maxNY=4, powerLimits = [-4,  4, -5, 5])
    contrastplot.logLog(1, pathlens,contrast,"","Range [m]",
        "Contrast",
             maxNX=10, maxNY=4, powerLimits = [-4,  4, -5, 5])

    contrastplot.saveFig('contrastplot{0}.eps'.format(caseAbbrev[colour]))

