function y=planckql(x,t)
%
% Planck's law in wavelength domain, in photon emittance 
%
% globals: None
%
% parameters:
% x == wavelength vector in  [um]
% t == temperature scalar in [K]
%
% returns :
% spectral emittance  in  q/s.m^2.um

% CJ Willers 1998-10-26, revised 2008-04-07

y=1.88365e27 ./ (x .^ 4 .* ( exp(14387.86 ./(x * t))-1));


