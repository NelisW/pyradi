function y=dplnckel(x,t)
% Planck's law derivative wrt temp in wavelength domain, 
% in radiant emittance 
%
% input parameters:
% x == wavelength vector in  [um]
% t == temperature scalar in [K]

% returns :
% spectral emittance/K  in  [W/Km^2.um]

xx=14387.86 ./(x * t);

y=(3.7418301e8 .* xx .* exp(xx) )./ (t.* x .^ 5 .* (exp(xx)-1) .^2 );





