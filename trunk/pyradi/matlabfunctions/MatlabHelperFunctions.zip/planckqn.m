function y=planckqn(x,t)
% planckqn(x,t)
% Planck's law in wavenumber domain, in photon emittance 
%
% globals: None
%
% parameters:
% x == wavenumber vector in  [cm^-1]
% t == temperature scalar in [K]
%
% returns :
% spectral emittance  in  q/s.m^2.cm^-1

% CJ Willers 1998-10-26, revised 2008-04-07
 
y=1.883635e15 .* x .^2 ./ (exp(1.438786 .* x ./t)-1);


