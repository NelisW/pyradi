function y=dplnckql(x,t)
% Planck's law derivative wrt temperature in wavelength domain, 
% in photon emittance 
%
% input parameters:
% x == wavelength vector in  [um]
% t == temperature scalar in [K]
%
% returns :
% spectral emittance/K  in  [q/Ks.m^2.um]

xx=(14387.86 ./(x * t));
f=xx.*exp(xx)./(t.*(exp(xx)-1));
y=1.88365e27 ./ (x .^ 4 .* ( exp(14387.86 ./(x * t))-1));
y=f.*y;
