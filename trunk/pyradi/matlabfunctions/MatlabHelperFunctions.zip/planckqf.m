function y=planckqf(x,t)
% planckqf(x,t)
% Planck's law in frequency domain, in photon emittance 
%
% globals: None
%
% parameters:
% x == frequency vector in  [Hz]
% t == temperature scalar in [K]
%
% returns :
% spectral emittance  in  q/s.m^2.Hz

% CJ Willers 1998-10-26

y=6.9911e-17 .* x .^2 ./ (exp(4.79927e-11 .* x ./t)-1);




