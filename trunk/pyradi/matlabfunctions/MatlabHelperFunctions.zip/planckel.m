function y=planckel(x,t)
%
% Planck's law in wavelength domain, in radiant emittance 
%
% parameters:
% x == wavelength vector in  [um]
% t == temperature scalar in [K]
%
% returns :
% spectral emittance  in  W/m^2.um

% CJ Willers 1998-10-26, revised 2008-04-07

y=3.7418301e8 ./ (x .^ 5 .* ( exp(14387.86 ./(x * t))-1));


