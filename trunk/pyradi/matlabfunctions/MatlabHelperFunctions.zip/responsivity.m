function y=responsivity(lp,n,a,k,l)
%function y=responsivity(lp,n,a,k,l)
% this function returns a vector  describing a photon detector in 
% the wavelength and radiant domains.
%
% inputs:
% scalar lp  something like the wavelength for peak responsivity
% scalar n   5<n<50
% scalar a   0<a<5
% scalar k   scaling constant
% vector l   wavelength vector.  !! must be wavelength  !!
%
% outputs
% responsivity vector


   rd=k *( ( l ./ lp) .^a - ( l ./ lp) .^ n);
   y= rd .* (rd > 0);

