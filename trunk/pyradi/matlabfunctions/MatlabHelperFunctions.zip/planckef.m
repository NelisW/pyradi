function y=planckef(x,t)
% planckef(x,t)
% Planck's law in frequency domain, in radiant emittance 
%
% globals: None
%
% parameters:
% x == frequency vector in  [Hz]
% t == temperature scalar in [K]
%
% returns :
% spectral emittance  in  W/m^2.Hz

% CJ Willers 1998-10-26


y=4.6323506e-50 .* x .^3 ./ (exp(4.79927e-11 .* x ./t)-1);




