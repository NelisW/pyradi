%  SFILTER.M
%  y=sfilter(b,t,s,d,c,w)

%  this file returns a filter vector 
%  The filter is assumed to be maximally flat, 
%    i.e. no ripple in the passband.  The filter response can be any 
%    symmetrical shape between a Gaussian and a square.
%
% inputs:
%   
%  scalar:   b     :  the transmittance in the stop bands (assumed constant)
%  scalar:   t     :  peak transmittance in the pass band (assumed constant)
%  scalar:   s     :  define the sharpness of cutoff. 
%                          If b=2        then gaussian
%                          If b=infinity then square 
%  scalar:   d     :  Proportional to filter width
%  scalar:   c     :  center wavelength
%  vector:   w     :  vector of wavelength/wavenumber values
%
% returns:
%  vector:   filter:  vector of transmittances at wavelengths w.
%
% 97-12-01 CJ Willers +27-12-6711279 wile@kidd.co.za
%



function y=sfilter(b,t,s,d,c,w)

  y = b+t*exp(-(2*(w-c)/d).^s)';
  y = t*y./(max(y));

