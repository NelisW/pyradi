function y=dplnckef(x,t)
% Planck's law derivative wrt temperature in frequency domain, 
% in radiant emittance 
%
% input parameters:
% x == frequency vector in  [Hz]
% t == temperature scalar in [K]
%
% returns :
% spectral emittance/K  in  [W/Km^2.Hz]

xx=(4.79927e-11 .* x ./t);
f=xx.*exp(xx)./(t.*(exp(xx)-1));
y=4.6323506e-50 .* x .^3 ./ (exp(4.79927e-11 .* x ./t)-1);
y=f.*y;
