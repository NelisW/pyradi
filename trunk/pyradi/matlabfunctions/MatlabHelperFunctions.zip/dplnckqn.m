function y=dplnckqn(x,t)
% Planck's law derivative wrt temperature, 
% in wavenumber domain, in photon emittance 
%
% input parameters:
% x == wavenumber vector in  [cm^-1]
% t == temperature scalar in [K]
%
% returns :
% temperature derivative of spectral emittance  in  [q/Ks.m^2.cm^-1]

xx=(1.438786 .* x ./t);
f=xx.*exp(xx)./(t.*(exp(xx)-1));
y=1.883635e15 .* x .^2 ./ (exp(1.438786 .* x ./t)-1);
y=f.*y;
