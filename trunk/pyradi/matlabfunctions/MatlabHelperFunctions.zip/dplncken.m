function y=dplncken(x,t)
% Planck's law derivative wrt temperature in wavenumber domain, 
% in radiant emittance 

% input parameters:
% x == wavenumber vector in  [cm^-1]
% t == temperature scalar in [K]

% returns :
% spectral emittance/K  in  [W/Km^2.cm^-1]

xx=(1.438786 .* x ./t);
f=xx.*exp(xx)./(t.*(exp(xx)-1));
y=(3.7418e-8 .* x .^3 ./ (exp(1.438786 .* x ./t)-1));
y=f.*y;

