function y=dplnckqf(x,t)
% Planck's law derivative wrt temperature in frequency domain,
% in photon emittance 
%
% input parameters:
% x == frequency vector in  [Hz]
% t == temperature scalar in [K]
%
% returns :
% spectral emittance/K  in  [q/Ks.m^2.Hz]

xx=(4.79927e-11 .* x ./t);
f=xx.*exp(xx)./(t.*(exp(xx)-1));
y=6.9911e-17 .* x .^2 ./ (exp(4.79927e-11 .* x ./t)-1);
y=f.*y;




