function y=plancken(x,t)
% plancken(x,t)
% Planck's law in wavenumber domain, in radiant emittance 
%
% globals: None
%
% parameters:
% x == wavenumber vector in  [cm^-1]
% t == temperature scalar in [K]
%
% returns :
% spectral emittance  in  W/m^2.cm^-1

% CJ Willers 1998-10-26, revised 2008-04-07

y=3.7418e-8 .* x .^3 ./ (exp(1.438786 .* x ./t)-1);


