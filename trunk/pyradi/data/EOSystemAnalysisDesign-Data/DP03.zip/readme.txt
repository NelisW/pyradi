Modtran tropical, 23 km rural aerosol.
Horizontal path, 5 km, at sea level.

The transmittance is the second column the tape7 file.
The data is sampled at 1 cm-1, which is very dense, try to convolve the transmittance data with a spectral filter of the same width as your blackbody sample intervals.
See Section 7.4 in the book.
