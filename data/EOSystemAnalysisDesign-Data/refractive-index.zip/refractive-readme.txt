The information in this zip file was downloaded from:
http://refractiveindex.info/
i.e., as in 
http://refractiveindex.info/?group=METALS&material=Gold

In these files the wavelength is given in micro-meter.


